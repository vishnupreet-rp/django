from django.apps import AppConfig


class AdditionConfig(AppConfig):
    name = 'addition'
