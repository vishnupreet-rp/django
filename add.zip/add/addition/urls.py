from django.urls import path
from .views import addition, show_result

urlpatterns = [
    path('', addition, name='add'),
    path('result', show_result, name = 'result')
]
