from django.shortcuts import render
from django.http import HttpResponse


# Create your views here.
def addition(request):
    return render(request, 'result.html')


def show_result(request):
    val1 = int(request.GET['num1'])
    val2 = int(request.GET['num2'])
    res = val1 + val2

    return render(request, 'result1.html', {'Result': res})
